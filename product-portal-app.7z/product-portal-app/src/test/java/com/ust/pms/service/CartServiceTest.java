package com.ust.pms.service;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.UstSpringMvcProductApplication;
import com.ust.pms.model.Product;
import com.ust.pms.model.ShoppingCart;

import lombok.extern.log4j.Log4j2;

@Log4j2
@SpringBootTest(classes= UstSpringMvcProductApplication.class)
class CartServiceTest {

	@Autowired
	private CartService cartService;
	
	@Autowired
	private ProductService productService;
	
	@Before
	public void setUp() {
		 productService = new ProductService();
		 cartService = new CartService();
	}

	@AfterEach
	void tearDown() throws Exception {
		productService= null;
		cartService = null;
	}


	@Test
	void testDeleteCartItem() {
		Product product = new Product(777, "TestProduct", 2, 1892); // Adding a test Product Product(productId,ProductName,Quantity,Price)
		productService.saveProduct(product);						
		ShoppingCart cart = cartService.addToCart("777","TestProduct","1", "1", "120",70707); // Adding a test Product to Cart productId,ProductName,Quantity,QuantityCart,userId)
		log.info("###Inside testDeleteCartItem(): Cart Item Added: "+cart.getPdoductName());
		cartService.deleteCartItem(cart.getCartId(),"1","777");								  // Delete a added CartItem (cartId,QuantityInCart,ProductID)
		assertTrue(!cartService.isCartItemExists(cart.getCartId()));						 // assert True if the deleted product doesnot exist in cart
		productService.deleteProduct(777);													  // Delete test Product 
	}

	@Test
	void testGetCartItemsById() {
		Product product = new Product(777, "TestProduct", 2, 1892);
		productService.saveProduct(product);
		ShoppingCart cart = cartService.addToCart("777","TestProduct","1", "1", "120",70707);
		int cartIdAdded = cart.getCartId();
		cart =cartService.getCartItemsById(cart.getCartId());
		int cartIdRetrieved = cart.getCartId();
		log.info("###Inside: testGetCartItemsById(): CartAdded: "+cartIdAdded +" Cart Retrieved: "+cartIdRetrieved);
		assertTrue(cartIdAdded == cartIdRetrieved);
		cartService.deleteCartItem(cart.getCartId(),"1","777");
		productService.deleteProduct(777);
	}

	@Test
	void testAddToCart() throws Exception {
		Product product = new Product(777, "TestProduct", 2, 1892);
		productService.saveProduct(product);
		ShoppingCart cart = cartService.addToCart("777","TestProduct","1", "1", "120",70707);
		log.info("###Inside testAddToCart(): Cart Item After AddToCart: "+cart.getPdoductName());
		assertTrue("777".equals(cart.getProductIds()));
		cartService.deleteCartItem(cart.getCartId(),"1","777");
		productService.deleteProduct(777);
	}
	
	@Test
	void testUpdateCartItem() {
		Product product = new Product(777, "TestProduct", 5, 1892);
		productService.saveProduct(product);
		ShoppingCart cartItem = cartService.addToCart("777","TestProduct","1", "1", "120",70707);
		log.info("###Inside testUpdateCartItem(): Cart quantity Before Update: "+cartItem.getQuantityInCart());
		cartItem  = cartService.updateCartItem(String.valueOf(cartItem.getCartId()), "2", "777");
		log.info("###Inside testUpdateCartItem(): Cart quantity After Update: "+cartItem.getQuantityInCart());
		assertTrue("777".equals(cartItem.getProductIds()) && cartItem.getQuantityInCart()==2);
		cartService.deleteCartItem(cartItem.getCartId(),"1","777");
		productService.deleteProduct(777);
	}


	

}

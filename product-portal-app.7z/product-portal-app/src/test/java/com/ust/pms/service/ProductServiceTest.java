package com.ust.pms.service;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.UstSpringMvcProductApplication;
import com.ust.pms.model.Product;

import lombok.extern.log4j.Log4j2;
@Log4j2
@SpringBootTest(classes= UstSpringMvcProductApplication.class)
class ProductServiceTest{

	@Autowired
	ProductService productService;

	@Before
	public void setUp() {
		 productService = new ProductService();
	}

	@AfterEach
	void tearDown() throws Exception {
		productService= null;
	}


	@Test
	public void testGetProduct() throws Exception {
		Product product = new Product(777, "TestProduct", 2, 1892); // Adding a test Product Product(productId,ProductName,Quantity,Price)
		productService.saveProduct(product);						// Save test Product 
		Product result = productService.getProduct(777);			// Get test Product
		log.info("###Inside testGetProduct(): Product  Retrieved: "+result.getProductId());
		assertTrue(result.getProductId() == 777);					// Assert True if Product retrieved is same
		productService.deleteProduct(777);							// Delete test Product 
	}

	@Test
	void testSaveProduct() {
		Product product = new Product(777, "TestProduct", 2, 1892);
		productService.saveProduct(product);
		assertTrue(productService.isProductExists(777));
		log.info("###Inside testSaveProduct(): Product Exist After Save: "+productService.isProductExists(777));
		productService.deleteProduct(777);
	}

	@Test
	void testDeleteProduct() {
		Product product = new Product(777, "TestProduct", 2, 1892);
		productService.saveProduct(product);
		productService.deleteProduct(777);
		Boolean result = productService.isProductExists(777);
		log.info("###Inside testDeleteProduct():  Product Exist After Delete: "+productService.isProductExists(777));
		assertTrue(!result);
		
	}

	@Test
	void testUpdateProduct() {
		Product product = new Product(777, "TestProduct", 2, 1892);
		product = productService.saveProduct(product);
		log.info("###Inside testUpdateProduct():  Product Name Before Update: "+product.getProductName());
		Product updatedProduct = new Product(777, "UpdatedProduct", 2, 1892);
		productService.updateProduct(updatedProduct);
		Product result = productService.getProduct(777);
		log.info("###Inside testUpdateProduct():  Product Name After Update: "+result.getProductName());
		assertTrue(result.getProductName().equalsIgnoreCase("UpdatedProduct"));
		productService.deleteProduct(777);
	}



}

package com.pms.ust.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Product;
import com.ust.pms.model.ShoppingCart;
import com.ust.pms.service.CartService;
import com.ust.pms.service.ProductService;
import com.ust.pms.service.UserDataService;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;
	
	@Autowired
	CartService cartService;
	
	@Autowired
	UserDataService userDataService;

	@RequestMapping("/addproduct")
	public ModelAndView addProduct() {
		ModelAndView view = new ModelAndView();
		view.setViewName("product");
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
			view.addObject("command", new Product());
			view.addObject("isAdmin",userDataService.isAdmin());
		return view;
	}

	@RequestMapping("/saveProduct")
	public ModelAndView saveProduct(Product product) {
		int prdId = product.getProductId();
		ModelAndView view = new ModelAndView();
		view.setViewName("product");
		if (productService.isProductExists(prdId)) {
			view.addObject("command", new Product());
			view.addObject("message", "Product "+ prdId+" Updated Successfully!");
		} else {
			view.addObject("command", new Product());
			view.addObject("message", "Product " + prdId+" saved!");
		}
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		view.addObject("isAdmin",userDataService.isAdmin());
		productService.saveProduct(product);
		return view;
	}

	@RequestMapping("/fetchproductForm")
	public ModelAndView fetchproductByID() {
		
		ModelAndView view = new ModelAndView();
		view.setViewName("fetchproductByID");
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		view.addObject("isAdmin",userDataService.isAdmin());
		view.addObject("command", new Product());
		return view;
	}

	@RequestMapping("/fetchproductFormSave")
	public ModelAndView fetchproductByIDSave() {
		
		ModelAndView view = new ModelAndView();
		view.setViewName("product");
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		view.addObject("isAdmin",userDataService.isAdmin());
		view.addObject("command", new Product());
		return view;
	}
	@RequestMapping("/fetchProductsById")
	public ModelAndView fetchproduct(Product product) {
		int prdId = product.getProductId();
		ModelAndView view = new ModelAndView();

		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("fetchproductByID");
		if (productService.isProductExists(prdId)) {
			Product productDetails = productService.getProduct(prdId);
			view.addObject("command", productDetails);
			view.addObject("fetchExist", true);
		} else {
			view.addObject("command", new Product());
			view.addObject("message", "Product doesnot exist with Product ID: " + prdId);
		}
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		return view;
	}
	@RequestMapping("/addtocartById")
	public ModelAndView fetchAndAddtoCart(Product product) {

		ModelAndView view = new ModelAndView();
		String pid = String.valueOf(product.getProductId());
		String price = String.valueOf(product.getPrice());
		cartService.addToCart(pid,product.getProductName(),"1",
				"1",price,cartService.getUserOfCart());
		//update product table 
		int productQuantity = Integer.parseInt("1");
		productService.updateProductQuantity(pid,productQuantity,"SUB");
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		if(cartItems.isEmpty()) {
			view.addObject("emptyCart", "Your Shopping Cart is Empty. ");
		}else {

			if(cartItems.size()>=10) 
				view.addObject("cartfull","Your cart is full. Checkout some items!");

		}
		view.addObject("cartItems", cartItems);
		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("goToCart");
		return view;
	}
	@RequestMapping("/fetchProductsByIdSave")
	public ModelAndView fetchproductSave(Product product) {
		int prdId = product.getProductId();
		ModelAndView view = new ModelAndView();

		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("product");
		if (productService.isProductExists(prdId)) {
			Product productDetails = productService.getProduct(prdId);
			view.addObject("fetchExist", true);
			view.addObject("command", productDetails);
		} else {
			view.addObject("command", new Product());
			view.addObject("message", "Product doesnot exist with Product ID: " + prdId);
		}
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		return view;
	}
	
	// delete product by ProductId------- spring MVC
	@RequestMapping("/deleteProductById")
	public ModelAndView deleteProductById(Product product) {
		int prdId = product.getProductId();
		ModelAndView view = new ModelAndView();
		view.setViewName("fetchproductByID");
		view.addObject("command", new Product());
		if (productService.isProductExists(prdId)) {
			productService.deleteProduct(prdId);
			view.addObject("message", "Product with Product ID: " + prdId+" deleted!");
		} else {

			view.addObject("message", "Product doesnot exist with Product ID: " + prdId);
		}
		view.addObject("isAdmin",userDataService.isAdmin());
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		return view;
	}

	@RequestMapping("/viewAllProducts")
	public ModelAndView viewAllProducts() {
		List<Product> products = productService.getProducts();
		return new ModelAndView("viewAllProducts","products",products);
	}



	@RequestMapping("/delete/{productId}")
	public ModelAndView deleteProduct(@PathVariable("productId")String productId) {
		int prdId = Integer.parseInt(productId);
		ModelAndView view = new ModelAndView();
		if (productService.isProductExists(prdId)) {
			productService.deleteProduct(prdId);
			view.addObject("message", "Product with Product ID: " + prdId+" deleted!");
		} else {

			view.addObject("message", "Product doesnot exist with Product ID: " + prdId);

		}
		List<Product> products = productService.getProducts();
		view.addObject("products", products);
		view.addObject("isAdmin",userDataService.isAdmin());
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		view.setViewName("testpanel");
		return view;
	}
	
	
	@RequestMapping("/searchByName")
	public ModelAndView searchByName(Product product) {
		int prdId = product.getProductId();
		ModelAndView view = new ModelAndView();
		System.out.println(product.getProductName()+"###################");
		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("fetchproductByID");
		if (productService.isProductExists(prdId)) {
			List<Product> products = productService.searchProductsByName(product.getProductName());
			view.addObject("products", products);
		} else {
			view.addObject("command", new Product());
			view.addObject("message", "Product doesnot exist with Product ID: " + prdId);
		}
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		return view;
	}
}

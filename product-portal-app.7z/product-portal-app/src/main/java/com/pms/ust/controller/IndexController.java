package com.pms.ust.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pms.ust.email.EmailService;
import com.ust.pms.model.Product;
import com.ust.pms.model.ShoppingCart;
import com.ust.pms.model.UserRegistration;
import com.ust.pms.service.CartService;
import com.ust.pms.service.ProductService;
import com.ust.pms.service.UserDataService;

@Controller
public class IndexController {

	@Autowired
	UserDataService userDataService;

	@Autowired
	ProductService productService;

	@Autowired
	CartService cartService;

	@RequestMapping("/prd")
	public String showProducts() {
		return "product";
	}


	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout) {

		if (error != null) {
			model.addAttribute("errorMsg", "Incorrect username or password.Try again!");
		}
		if (logout != null) {
			model.addAttribute("msg", "You have been successfully logged out!");

		}
		return "login";

	}

	@RequestMapping("/")
	public ModelAndView index() {
		String username = "";
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();

		}
		ModelAndView model = new ModelAndView();
		List<Product> products = productService.getProducts();
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		model.addObject("cartItems", cartItems);
		model.addObject("products", products);
		model.addObject("username", username);
		model.addObject("isAdmin", userDataService.isAdmin());
		model.setViewName("index");

		return model;
	}

	@RequestMapping("/index")
	public ModelAndView showindex() {
		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();

		}
		;
		ModelAndView model = new ModelAndView();
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		model.addObject("cartItems", cartItems);
		model.addObject("username", username);
		model.setViewName("index");

		return model;
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register() {
		return new ModelAndView("registration", "user", new UserRegistration());
	}

	@Autowired
	JdbcUserDetailsManager jdbcUserDetailsManager;

	@Autowired
	EmailService emailService;

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView postRegister(UserRegistration userRegistration) {

		List<GrantedAuthority> authorities = new ArrayList<>();
		if (userRegistration.getRole().equals("USER")) {
			authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
		} else {
			authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		}
		User user = new User(userRegistration.getUsername(), userRegistration.getPassword(), authorities);
		jdbcUserDetailsManager.createUser(user);
		userDataService.saveUserData(userRegistration);
		if (userRegistration.getRole().equals("USER")) {
			emailService.sendEmailToUsers(userRegistration.getEmail(), "ProductPortal Registration successful! :)",
					userRegistration.getFirstName() + " " + userRegistration.getLastName());

		}

		return new ModelAndView("login", "message", "User registration successful.Please login to proceed.");
	}

}

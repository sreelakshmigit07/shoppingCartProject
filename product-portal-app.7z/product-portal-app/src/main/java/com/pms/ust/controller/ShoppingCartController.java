package com.pms.ust.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.ShoppingCart;
import com.ust.pms.service.CartService;
import com.ust.pms.service.CustomerDataService;
import com.ust.pms.service.ProductService;
import com.ust.pms.service.UserDataService;

@Controller
public class ShoppingCartController {
	
	
	@Autowired
	CartService cartService;
	
	@Autowired
	ProductService productService;
	
	@Autowired
	UserDataService userDataService;
	
	@Autowired
	CustomerDataService customerDataService;
	
	
	@RequestMapping("/addtocart")
	public ModelAndView addtoCart(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		ModelAndView view = new ModelAndView();
		List<ShoppingCart> cartItemsbefore = cartService.getAllProducts();
		if(cartItemsbefore.size()<=9) {
			if(request.getParameter("productId") != null && !request.getParameter("productId").isEmpty()) { // single product for adding to cart
				cartService.addToCart(request.getParameter("productId"),request.getParameter("productName"),request.getParameter("availQuantity"),
						request.getParameter("quantity"),request.getParameter("price"),cartService.getUserOfCart());
				//update product table 
				int productQuantity = Integer.parseInt(request.getParameter("quantity"));
				productService.updateProductQuantity(request.getParameter("productId"),productQuantity,"SUB");
			}else if(request.getParameter("myid")  != null && !request.getParameter("myid").isEmpty() ) { // multiple product ids from checkbox products
				String[] productReqst = request.getParameter("myid").split(",");
				int isCartfull = cartItemsbefore.size();
				for(String prod: productReqst ) {
					if(isCartfull<10) {
						isCartfull+=1;
						cartService.addToCart(prod,"","","1","",cartService.getUserOfCart());
						productService.updateProductQuantity(prod,1,"SUB");
					}
				}
			}
		}
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		if(cartItems.isEmpty()) {
			view.addObject("emptyCart", "Your Shopping Cart is Empty. ");
			view.addObject("sumTotal","0.00");
			customerDataService.sendCartMail(cartItems,false);
		}else {
			view.addObject("cartItems", cartItems);
			view.addObject("sumTotal",cartService.subTotal(cartItems));
			if(cartItems.size()>=10) {
				view.addObject("cartfull","Your cart is full. Checkout some items!");
				customerDataService.sendCartMail(cartItems,false);
			}
		}
		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("goToCart");
		return view;


	}
	@RequestMapping(value = "/updatecart",  params = "remove")
	public ModelAndView removeFromCart(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		int cartId = Integer.parseInt(request.getParameter("cartId"));
		ModelAndView view = new ModelAndView();
		cartService.deleteCartItem(cartId,request.getParameter("quantityInCart"),request.getParameter("productIds"));
		view.addObject("message", "Item "+cartId+" Removed from cart " );
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		if(cartItems.isEmpty()) {
			view.addObject("emptyCart", "Your Shopping Cart is Empty. ");
			view.addObject("sumTotal","0.00");
			customerDataService.sendCartMail(cartItems,false);
		}else {
			view.addObject("cartItems", cartItems);
			view.addObject("sumTotal",cartService.subTotal(cartItems));
		}
		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("goToCart");
		return view;
	}

	@RequestMapping(value = "/updatecart",  params = "update")
	public ModelAndView updateCart(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		int productId = Integer.parseInt(request.getParameter("productIds"));
		ModelAndView view = new ModelAndView();
		if(productService.isProductExists(productId)) {
			cartService.updateCartItem(request.getParameter("cartId"),request.getParameter("quantityInCart"),request.getParameter("productIds"));
			view.addObject("message", request.getParameter("pdoductName")+" - Cart Item updated!" );
		}else {
			view.addObject("message", "Item '"+request.getParameter("pdoductName")+"' currently not available. " );
		}
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		if(cartItems.isEmpty()) {
			view.addObject("emptyCart", "Your Shopping Cart is Empty. ");
			view.addObject("sumTotal","0.00");
		}else {
			view.addObject("cartItems", cartItems);
			view.addObject("sumTotal",cartService.subTotal(cartItems));
		}
		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("goToCart");
		return view;
	}
	@RequestMapping("/addalltocart")
	public ModelAndView addalltoCart(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		ModelAndView view = new ModelAndView();
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		if(cartItems.isEmpty()) {
			view.addObject("emptyCart", "Your Shopping Cart is Empty. ");
			view.addObject("sumTotal","0.00");
		}else {
			view.addObject("cartItems", cartItems);
			view.addObject("sumTotal",cartService.subTotal(cartItems));
		}
		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("goToCart");
		return view;


	}
	
	@RequestMapping("/checkoutConfirm")
	public ModelAndView checkoutConfirm() {

		ModelAndView view = new ModelAndView();
		cartService.deleteCartItemOnConfirm();
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		if(cartItems.isEmpty()) {
			view.addObject("emptyCart", "Your Shopping Cart is Empty. ");
			view.addObject("sumTotal","0.00");
		}else {
			view.addObject("cartItems", cartItems);
			view.addObject("sumTotal",cartService.subTotal(cartItems));
		}

		view.addObject("isAdmin",userDataService.isAdmin());
		view.addObject("checkoutConfirm","Your Order has been placed!");
		view.setViewName("goToCart");
		return view;

	}
}

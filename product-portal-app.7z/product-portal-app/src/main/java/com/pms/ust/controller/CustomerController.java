package com.pms.ust.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.CustomerData;
import com.ust.pms.model.ShoppingCart;
import com.ust.pms.service.CartService;
import com.ust.pms.service.UserDataService;

@Controller
public class CustomerController {

	@Autowired
	UserDataService userDataService;
	
	@Autowired
	CartService cartService;
	
	@RequestMapping("/accountDetail")
	public ModelAndView accountDetails() {
		
		ModelAndView view = new ModelAndView();
		String username = userDataService.getUserFromPrincipal();
		List<CustomerData> customer = userDataService.findByUsername(username);
		view.addObject("isAdmin",userDataService.isAdmin());
		view.setViewName("accountDetail");
		view.addObject("customer", customer);
		List<ShoppingCart> cartItems = cartService.getAllProducts();
		view.addObject("cartItems", cartItems);
		return view;
	}
}

package com.ust.pms.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class ShoppingCart {
	
	@Id
	@GeneratedValue
	private int cartId;
	private String productIds;
	private String pdoductName;
	
	private int userId;
	private int quantityInCart;
	private float price;
	
	
	
}

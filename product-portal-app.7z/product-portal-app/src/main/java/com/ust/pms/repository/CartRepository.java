package com.ust.pms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ust.pms.model.ShoppingCart;


public interface CartRepository extends CrudRepository<ShoppingCart,Integer> {

	@Query("SELECT u FROM ShoppingCart u WHERE u.userId = :userId ")
	List<ShoppingCart> getCartItemsByUserId(@Param("userId") int userId);

	@Query("SELECT u FROM ShoppingCart u WHERE u.cartId = :cartId ")
	ShoppingCart getCartItemsByCartId(@Param("cartId")int cartId);

	@Query("SELECT u FROM ShoppingCart u WHERE u.productIds like :productIds and u.userId = :userId ")
	List<ShoppingCart>  isProductExistInCart(@Param("productIds")String pid, @Param("userId")int userId);
	
	
	
}

package com.ust.pms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.ust.pms.model.CustomerData;
import com.ust.pms.model.UserRegistration;
import com.ust.pms.repository.CartRepository;
import com.ust.pms.repository.CustomerDataRepository;
import com.ust.pms.repository.UserDataRepository;

@Service
public class UserDataService {
	
	@Autowired
	UserDataRepository userDataRepository;
	
	@Autowired
	CartRepository cartRepository;
	
	@Autowired
	CustomerDataRepository customerDataRepository;
	
	public void saveUserData(UserRegistration userRegistration) {
		
		CustomerData userData = new CustomerData();
		userData.setUsername(userRegistration.getUsername());
		userData.setFirstName(userRegistration.getFirstName());
		userData.setLastName(userRegistration.getLastName());
		userData.setEmail(userRegistration.getEmail());
		
		customerDataRepository.save(userData);
	}
	
	public List<CustomerData> findByUsername(String username) {
		return userDataRepository.findDataByUsername(username);
	}
	public String getUserFromPrincipal() {
		String username=null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(	principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
			
		}
		return username;
	}
	public Boolean isAdmin() {
		Collection<? extends GrantedAuthority> role = new ArrayList<GrantedAuthority>();
		 Boolean isAdmin = false;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(	principal instanceof UserDetails) {
			role = ((UserDetails) principal).getAuthorities();
		}
		if(role.contains(new SimpleGrantedAuthority("ROLE_ADMIN"))) {
			isAdmin = true;
		}
		return isAdmin;
	}

}

package com.ust.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.ust.email.EmailService;
import com.ust.pms.model.CustomerData;
import com.ust.pms.model.ShoppingCart;
import com.ust.pms.repository.CustomerDataRepository;

@Service
public class CustomerDataService {

	@Autowired
	EmailService emailService;

	@Autowired
	CustomerDataRepository customerDataRepository;

	@Autowired
	UserDataService userDataService;

	public void sendCartMail(List<ShoppingCart> cartItems,Boolean isCheckout) {

		CustomerData customer = getCustomerDetails();
		emailService.sendCartDetails(cartItems, customer.getEmail(), "PRODUCT_PORTAL-CART DETAILS",
				customer.getFirstName() + " " + customer.getLastName(),isCheckout);

	}

	public CustomerData getCustomerDetails() { // List<Product> findByProductName(String productName);

		String username = userDataService.getUserFromPrincipal();
		return customerDataRepository.findByUsername(username);
	}

}

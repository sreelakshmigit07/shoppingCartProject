package com.ust.pms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.ust.email.EmailService;
import com.ust.pms.model.CustomerData;
import com.ust.pms.model.Product;
import com.ust.pms.model.ShoppingCart;
import com.ust.pms.repository.CartRepository;

@Service
public class CartService {

	@Autowired
	CartRepository cartRepository;

	@Autowired
	UserDataService userDataService;

	@Autowired
	EmailService emailService;

	@Autowired
	ProductService productService;

	@Autowired
	CustomerDataService customerDataService;

	public void deleteCartItem(int cartId, String quantity, String product) {
		cartRepository.deleteById(cartId);
		int cartQuantity = Integer.parseInt(quantity);
		if(productService.isProductExists(Integer.parseInt(product))) {
			productService.updateProductQuantity(product, cartQuantity, "ADD");
		}
	}

	public ShoppingCart getCartItemsById(int cartId) {
		return cartRepository.getCartItemsByCartId(cartId);
	}

	public Boolean isCartItemExists(int cartId) { // method to check whether the cartItem already exists. Returns true if already exists else returns false
		return cartRepository.existsById(cartId);
	}

	public ShoppingCart addToCart(String pid, String productName, String totalQuantity, String quantity, String price, int userId) {
		
		Product product = productService.getProduct(Integer.parseInt(pid));
		ShoppingCart cart = new ShoppingCart();
		List<ShoppingCart> cartItem = cartRepository.isProductExistInCart(pid, userId);
		if (cartItem != null && !cartItem.isEmpty()) {// check product already exist in the cart
			ShoppingCart existingCart = cartItem.get(0);
			cart.setCartId(existingCart.getCartId());
			cart.setQuantityInCart(Integer.sum(existingCart.getQuantityInCart(), Integer.parseInt(quantity)));
			cart.setPrice(cart.getQuantityInCart() * product.getPrice());
		} else {
			cart.setQuantityInCart(Integer.parseInt(quantity));
			cart.setPrice(product.getPrice() * cart.getQuantityInCart());
		}
		cart.setProductIds(pid);
		cart.setPdoductName(product.getProductName());
		cart.setUserId(userId);
		ShoppingCart newCartItem = cartRepository.save(cart);
		return newCartItem;
	}

	public List<ShoppingCart> getAllProducts() {
		String username = userDataService.getUserFromPrincipal();
		List<CustomerData> userList = userDataService.findByUsername(username);
		CustomerData userdata = userList.get(0);
		List<ShoppingCart> cartItems = cartRepository.getCartItemsByUserId(userdata.getUserId());

		return cartItems;
	}

	public ShoppingCart updateCartItem(String cartItem, String quantity, String product) {
		int cartId = Integer.parseInt(cartItem);
		int cartQuantity = Integer.parseInt(quantity);
		Optional<ShoppingCart> cart = cartRepository.findById(cartId);
		ShoppingCart shoppingCart = cart.get();
		Product productItem = new Product();
		if (cartQuantity > shoppingCart.getQuantityInCart()) { // if newCart
			int productQuantity = cartQuantity - shoppingCart.getQuantityInCart();
			productItem = productService.updateProductQuantity(product, productQuantity, "SUB");
		} else if (cartQuantity < shoppingCart.getQuantityInCart()) {
			int productQuantity = shoppingCart.getQuantityInCart() - cartQuantity;
			productItem = productService.updateProductQuantity(product, productQuantity, "ADD");
		}

		shoppingCart.setQuantityInCart(cartQuantity);
		shoppingCart.setPrice(shoppingCart.getQuantityInCart() * productItem.getPrice());
		ShoppingCart updatedCart = cartRepository.save(shoppingCart);
		return updatedCart;
	}

	public int subTotal(List<ShoppingCart> cartItems) {
		int total = cartItems.stream().map(pm -> pm.getPrice()).mapToInt(i -> i.intValue()).sum();
		return total;

	}

	public void deleteCartItemOnConfirm() {
		List<ShoppingCart> cartItems = getAllProducts();
		for (ShoppingCart cart : cartItems) {
			cartRepository.deleteById(cart.getCartId());
		}
		customerDataService.sendCartMail(cartItems, true);
	}

	public int getUserOfCart() {
		String username = userDataService.getUserFromPrincipal();
		List<CustomerData> userList = userDataService.findByUsername(username);
		CustomerData userdata = userList.get(0);
		return userdata.getUserId();
	}

}

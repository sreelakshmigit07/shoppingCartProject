package com.ust.pms.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ust.pms.model.Product;
import com.ust.pms.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	ProductRepository productRepository;

	public List<Product> getProducts(){ // get all products
		return (List<Product>) productRepository.findAll();
	}
	

	public Product getProduct(Integer productId) {  // get product by productId
		Optional<Product> product = productRepository.findById(productId);
		return product.get();
	}

	public Product saveProduct(Product product) {
		Product prd = productRepository.save(product);
		return prd;
	}

	public void deleteProduct(Integer productId) {
		productRepository.deleteById(productId);
		
	}

	public Product updateProduct(Product product) {  // update or save Product
		Product prd = productRepository.save(product);
		return prd;
	}


	public List<Product> searchProductsByName(String productName) {  // find by productName
		return productRepository.findByProductName(productName);
		
	}
	
	public List<Product> searchProductsPriceGreater(int price) {
		
		return productRepository.findByPriceGreaterThan(price);
		
	}
	
	public Boolean isProductExists(int productId) { // method to check whether the Product already exists. Returns true if already exists else returns false
		return productRepository.existsById(productId);
	}


	public Product updateProductQuantity(String productID, int quantityUsed,String action) {
		Product product = getProduct(Integer.parseInt(productID));
		int newQuantity = 0;
		if(action.equalsIgnoreCase("SUB")) {
			newQuantity =	product.getQuantityOnHand() - quantityUsed;
		}else if(action.equalsIgnoreCase("ADD")) {
			newQuantity =	product.getQuantityOnHand() + quantityUsed;
		}
		product.setQuantityOnHand(newQuantity);
		productRepository.save(product);
		return product;
		
	}
}
